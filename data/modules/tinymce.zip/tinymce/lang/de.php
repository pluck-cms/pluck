<?php
$lang['tinymce']['module_name'] = 'tinymce';
$lang['tinymce']['module_intro'] = 'Fügt den TinyMCE-Editor zu pluck hinzu. TinyMCE wurde entwickelt von <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a>.';
?>